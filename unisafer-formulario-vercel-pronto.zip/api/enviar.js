'use strict';
const { put, get } = require('@vercel/blob');
const { makePDF } = require('../lib/pdf');
const { sanitizeAnswers, safeFileName } = require('../lib/fields');

const DESTINATION = 'contato@unisafereducacional.com.br';
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'Método não permitido.' });
  // Requisições de sites terceiros não podem usar este endpoint via navegador.
  const origin = req.headers.origin;
  if (origin) {
    try { if (new URL(origin).host !== req.headers.host) return res.status(403).json({ ok: false, error: 'Origem não autorizada.' }); }
    catch (_) { return res.status(403).json({ ok: false, error: 'Origem não autorizada.' }); }
  }
  if (!String(req.headers['content-type'] || '').includes('application/json')) {
    return res.status(415).json({ ok: false, error: 'Envie os dados no formato JSON.' });
  }
  if (!process.env.BLOB_READ_WRITE_TOKEN || !process.env.RESEND_API_KEY || !process.env.MAIL_FROM) {
    return res.status(503).json({ ok: false, error: 'O recebimento está em configuração. Entre em contato com a Unisafer.' });
  }
  let data;
  try {
    data = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    if (JSON.stringify(data || {}).length > 28000) throw new Error('Formulário excedeu o limite de tamanho.');
    if (!data || !UUID_REGEX.test(data.submissionId || '')) throw new Error('Identificador de envio inválido.');
    if (typeof data.website !== 'string' || data.website.length > 0) throw new Error('Envio rejeitado.'); // honeypot
    if (data.privacyAccepted !== true) throw new Error('Confirme a leitura do aviso de privacidade.');
    const date = new Date(data.submittedAt);
    if (!Number.isFinite(date.getTime()) || Math.abs(Date.now() - date.getTime()) > 14 * 24 * 3600 * 1000) {
      throw new Error('Sua sessão expirou. Recarregue a página para preencher novamente.');
    }
    const answers = sanitizeAnswers(data.answers);
    data = { answers, submissionId: data.submissionId.toLowerCase(), submittedAt: date.toISOString() };
  } catch (err) {
    return res.status(400).json({ ok: false, error: err.message || 'Respostas inválidas.' });
  }
  const { answers, submissionId, submittedAt } = data;
  const base = safeFileName(answers.nome);
  const filename = `unisafer-${base}-${submissionId.slice(0, 8)}.pdf`;
  const prefix = submittedAt.slice(0, 7);
  const storagePath = `candidaturas/${prefix}/${base}-${submissionId}.pdf`;
  let pdf;
  try {
    const existing = await get(storagePath, { access: 'private' });
    if (existing?.statusCode === 200 && existing.stream) {
      pdf = Buffer.from(await new Response(existing.stream).arrayBuffer());
    } else {
      pdf = await makePDF({ answers, submittedAt, id: submissionId });
      // O armazenamento deve ser PRIVADO. Nunca usar 'public' para dados de candidatos.
      await put(storagePath, pdf, { access: 'private', addRandomSuffix: false, allowOverwrite: false,
        contentType: 'application/pdf' });
    }
  } catch (err) {
    console.error('Falha na geração ou armazenamento do PDF', { stage: 'storage', errorType: err?.name });
    return res.status(502).json({ ok: false, error: 'Não foi possível salvar a candidatura. Tente novamente.' });
  }

  const emailPayload = {
    from: process.env.MAIL_FROM,
    to: [DESTINATION],
    reply_to: answers.email,
    subject: `Candidatura comercial | ${answers.nome}`,
    text: [
      'Nova candidatura recebida pelo formulário Unisafer.',
      `Nome: ${answers.nome}`,
      `E-mail: ${answers.email}`,
      `WhatsApp: ${answers.telefone}`,
      `Cidade: ${answers.cidade}`,
      `Protocolo: ${submissionId}`,
      '',
      'O PDF completo com todas as respostas está anexado. Uma cópia privada foi salva no Vercel Blob.',
    ].join('\n'),
    attachments: [{ filename, content: pdf.toString('base64'), content_type: 'application/pdf' }],
  };
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json',
        'Idempotency-Key': `candidatura/${submissionId}` },
      body: JSON.stringify(emailPayload),
      signal: AbortSignal.timeout(12000),
    });
    if (!response.ok) {
      console.error('Falha no envio do e-mail', { stage: 'email', status: response.status });
      return res.status(502).json({ ok: false, saved: true,
        error: 'O formulário foi salvo, mas o envio do e-mail não foi confirmado. Tente novamente sem alterar as respostas.' });
    }
    return res.status(200).json({ ok: true, protocol: submissionId });
  } catch (err) {
    console.error('Erro de conexão no envio do e-mail', { stage: 'email', errorType: err?.name });
    return res.status(502).json({ ok: false, saved: true,
      error: 'O formulário foi salvo, mas o e-mail ainda não foi confirmado. Tente novamente sem alterar as respostas.' });
  }
};
