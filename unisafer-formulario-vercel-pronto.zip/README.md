# Formulário de Pré-seleção — Unisafer

Site HTML pronto para publicar na **Vercel**, com função Node.js que gera um **PDF para cada candidato**, salva uma cópia em **Vercel Blob privado** e envia o PDF anexo para **contato@unisafereducacional.com.br** usando **Resend**.

## Como funciona

1. O candidato acessa a página e preenche as quatro etapas.
2. Na última etapa, ele confirma a ciência do uso de dados e clica em **Concluir e enviar candidatura**.
3. `/api/enviar` valida os campos no servidor, produz um PDF com todos os 21 campos, grava em `candidaturas/AAAA-MM/nome-ID.pdf` em um bucket privado e solicita o envio de e-mail para a Unisafer com o PDF anexado.
4. O candidato só vê a mensagem de sucesso depois de o serviço de e-mail aceitar o envio. Recebe um número de protocolo na tela.
5. Se o e-mail falhar, o PDF já estará salvo e o formulário permite repetir o envio sem perder os dados. A chave de idempotência ajuda a evitar e-mails duplicados no período de 24 horas coberto pelo Resend.

**Importante:** o aceite do serviço de e-mail não garante entrega na caixa de entrada (verifique também spam e o painel Resend). Não há upload de currículo nesta versão: as respostas são enviadas automaticamente; currículos previamente recebidos podem ser relacionados pelo nome/e-mail.

## Publicação na Vercel

1. Crie um repositório **novo** no GitHub apenas para este formulário (não misture com o Portal R2 ou com o CRM da Unisafer).
2. Suba os arquivos desta pasta para a raiz do repositório.
3. Na Vercel, clique em **Add New > Project**, importe o repositório e escolha Framework Preset **Other**. Deixe Root Directory como `./`.
4. Em **Storage**, crie um **Blob store com acesso Private** e conecte ao projeto. A Vercel configurará o token do Blob para a função: `BLOB_READ_WRITE_TOKEN`.
5. No serviço **Resend**, verifique um endereço de remetente sob um domínio que você controla (ex.: `candidaturas@unisafereducacional.com.br`), realizando os ajustes DNS que o serviço solicitar. A caixa de entrada continuará sendo `contato@unisafereducacional.com.br`.
6. Em **Project > Settings > Environment Variables** na Vercel, configure as três variáveis a seguir no ambiente **Production** (e também em Preview se for testar por esse ambiente):
   - `BLOB_READ_WRITE_TOKEN`: fornecido pelo Blob **privado** conectado ao projeto.
   - `RESEND_API_KEY`: credencial secreta do Resend.
   - `MAIL_FROM`: remetente validado, por exemplo `Unisafer Selecao <candidaturas@unisafereducacional.com.br>`.
7. Faça um novo deploy após salvar as variáveis. Antes de divulgar o link, faça **uma candidatura de teste** e confirme: mensagem de sucesso, e-mail com PDF anexo, PDF com todas as respostas e arquivo no Blob privado.

Se faltar uma das variáveis, o formulário exibe erro de configuração, **sem fingir que a candidatura foi recebida**.

### Segurança / privacidade

- Os PDFs são armazenados em **Blob privado**, nunca publicamente. Não existe endpoint público de download de documentos.
- As credenciais ficam somente no backend da Vercel; nunca no HTML ou no GitHub.
- O servidor confere os campos, limita o tamanho do formulário e tem um *honeypot* básico contra robôs. **Antes de fazer divulgação pública em grande escala, implemente também proteção antiabuso/rate limit e CAPTCHA (como Cloudflare Turnstile).** O honeypot isolado não é suficiente para impedir spam deliberado.
- Planeje uma política de retenção/exclusão de candidaturas, com acesso aos PDFs restrito à equipe responsável, de acordo com a LGPD. O candidato já vê uma informação de privacidade e o contato para solicitações.
- Não divulgue no formulário o link direto do Blob nem crie store `public`.
- O endereço de destino está fixado no código do servidor para evitar manipulação do destinatário pelos candidatos.

### Estrutura

```text
index.html                 # Formulário e estilo original Unisafer
assets/unisafer-logo.png   # Logo azul oficial do formulário anterior
api/enviar.js              # Validação, PDF, storage privado, email
lib/fields.js              # Campos permitidos e regras
lib/pdf.js                 # Geração do PDF
package.json
vercel.json
.env.example
```

### Teste local

```bash
npm install
npm test
npx vercel dev
```

Para testar envio completo localmente, configure as variáveis em `.env.local` (não versionado) e tenha um Blob privado e uma conta de e-mail validados. **A entrega da integração externa não foi testada sem as credenciais reais.**
