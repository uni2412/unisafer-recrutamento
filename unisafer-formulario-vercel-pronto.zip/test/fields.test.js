'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { FIELDS, sanitizeAnswers, safeFileName } = require('../lib/fields');
const filled = Object.fromEntries(FIELDS.map(([label, key]) => [key, key === 'duvidas' ? '' : 'Exemplo de resposta suficiente']));
filled.nome = 'Maria da Silva';
filled.email = 'maria@example.com';
filled.telefone = '11999999999';

test('preserva os 21 campos, inclusive observação opcional', () => {
  assert.equal(FIELDS.length,21);
  assert.equal(Object.keys(sanitizeAnswers(filled)).length,21);
});
test('rejeita e-mail inválido', () => {
  assert.throws(() => sanitizeAnswers({...filled,email:'inválido'}),/E-mail inválido/);
});
test('rejeita campo obrigatório vazio', () => {
  assert.throws(() => sanitizeAnswers({...filled,motivacao:''}),/Preencha/);
});
test('rejeita objetos em campos de resposta', () => {
  assert.throws(() => sanitizeAnswers({...filled,duvidas:{foo:'x'}}),/Campo inválido/);
});
test('sanitiza o nome para o arquivo', () => {
  assert.equal(safeFileName('João / Maria?'), 'joao-maria');
});
