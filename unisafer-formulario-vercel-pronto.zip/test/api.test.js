'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const Module=require('node:module');
const {FIELDS}=require('../lib/fields');

function makeHandler({storageFail=false, emailFail=false, existingPdf=null}={}) {
  const path=require.resolve('../api/enviar');
  delete require.cache[path];
  let saved=[];
  let fetchPayload=null;
  const oldLoad=Module._load;
  Module._load=function(request,parent,isMain){
    if(request==='@vercel/blob')return {
      get:async()=>existingPdf ? {statusCode:200,stream:new Response(existingPdf).body}:null,
      put:async (key,bytes,opts)=>{if(storageFail)throw new Error('storage offline');saved.push({key,bytes,opts});}
    };
    if(request==='../lib/pdf' && parent.filename.endsWith('api/enviar.js'))return {
      makePDF:async()=>Buffer.from('%PDF-1.4 mocked')
    };
    return oldLoad.apply(this,arguments);
  };
  const handler=require('../api/enviar');
  Module._load=oldLoad;
  const previous=globalThis.fetch;
  globalThis.fetch=async (url,opts)=>{fetchPayload=JSON.parse(opts.body);return {ok:!emailFail,status:emailFail?401:200};};
  return {handler,saved,getEmail:()=>fetchPayload,cleanup:()=>{globalThis.fetch=previous;delete require.cache[path];}};
}
function reqData(){
  const answers=Object.fromEntries(FIELDS.map(([label,key])=>[key, key==='duvidas'?'':'Resposta para a pergunta do formulário de seleção.']));
  Object.assign(answers,{nome:'Maria da Silva',email:'maria@example.com',telefone:'11999999999'});
  return {method:'POST',headers:{host:'unisafer.vercel.app',origin:'https://unisafer.vercel.app','content-type':'application/json'},body:{answers,privacyAccepted:true,website:'',submissionId:'123e4567-e89b-42d3-a456-426614174000',submittedAt:new Date().toISOString()}};
}
function response(){return {code:200,setHeader(){},status(n){this.code=n;return this;},json(body){this.body=body;return this;}};}
const orig={...process.env};

test('salva PDF privado e envia anexo com nome do candidato',async()=>{
  process.env.BLOB_READ_WRITE_TOKEN='fake';process.env.RESEND_API_KEY='fake';process.env.MAIL_FROM='Teste <teste@example.com>';
  const app=makeHandler(),res=response();
  try{
    await app.handler(reqData(),res);
    assert.equal(res.code,200);assert.equal(res.body.ok,true);
    assert.equal(app.saved.length,1);assert.equal(app.saved[0].opts.access,'private');
    assert.equal(app.saved[0].opts.allowOverwrite,false);
    const mail=app.getEmail();assert.deepEqual(mail.to,['contato@unisafereducacional.com.br']);
    assert.match(mail.attachments[0].filename,/maria-da-silva/);
    assert.equal(mail.attachments[0].content_type,'application/pdf');
  }finally{app.cleanup()}
});
test('não confirma candidatura se falhar o salvamento',async()=>{
  process.env.BLOB_READ_WRITE_TOKEN='fake';process.env.RESEND_API_KEY='fake';process.env.MAIL_FROM='Teste <teste@example.com>';
  const app=makeHandler({storageFail:true}),res=response();
  try {await app.handler(reqData(),res);assert.equal(res.code,502);assert.equal(res.body.ok,false);assert.equal(app.getEmail(),null)}
  finally{app.cleanup()}
});
test('informa falha parcial quando PDF foi salvo mas e-mail falha',async()=>{
  process.env.BLOB_READ_WRITE_TOKEN='fake';process.env.RESEND_API_KEY='fake';process.env.MAIL_FROM='Teste <teste@example.com>';
  const app=makeHandler({emailFail:true}),res=response();
  try {await app.handler(reqData(),res);assert.equal(res.code,502);assert.equal(res.body.saved,true);assert.equal(app.saved.length,1)}
  finally{app.cleanup()}
});
test('bloqueia envio sem aceite de privacidade',async()=>{
  process.env.BLOB_READ_WRITE_TOKEN='fake';process.env.RESEND_API_KEY='fake';process.env.MAIL_FROM='Teste <teste@example.com>';
  const app=makeHandler(),res=response();
  try{const req=reqData();req.body.privacyAccepted=false;await app.handler(req,res);assert.equal(res.code,400);assert.equal(app.saved.length,0)}
  finally{app.cleanup()}
});
